README

INFO:
Map: sn_caldera_fix
Creator: UKFT | Benjy
Website: www.bencoveney.com

INSTALLATION:
To install the map copy the .bsp file to your tf2 maps directory.
This is usually C:\\Program Files\Steam\steamapps\common\Team Fortress 2\tf\maps\